
using tvShowPetProject.Services;
var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
// API call
builder.Services.AddHttpClient<ApiEndPointService>();
builder.Services.AddHttpClient<ActorEndPointService>();
// 
var app = builder.Build();
// App Rooute
// app.MapControllerRoute(
//     name: "default",
//     pattern: "{controller=TVShow}/{action=Detail}/{id?}");
// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Actor}/{action=Index}/{id?}")
    .WithStaticAssets();
app.Run();
