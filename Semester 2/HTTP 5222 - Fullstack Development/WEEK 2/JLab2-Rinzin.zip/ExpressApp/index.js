// Import the package
import express from "express";
import path from "path"; // the path module is used to get the path of the current file
console.log("sdf",path);
const __dirname = import.meta.dirname;

// Create an instance of express
const app = express();
const port = process.env.PORT || 9000;

// set up app to use Pug as the template engine
// app.set("views", path.join(__dirname, "templates")); //if you had your views/tempaltes in a folder named "templates"
app.set("view engine", "pug");
// Setup the "pubic" folder as a static path
app.use(express.static(path.join(__dirname, "public")));

// Create a home page route
app.get("/", (req, res) => {
    res.render("index",{ title: "My Secret Closet" });
});

app.get("/about", (req, res) => {
    res.render("about", { title: "About Us - Closet" });
});


// Start the server
app.listen(port, () => {
    // console.log("Server started on port 5000");
    console.log(`Server running at http://localhost:${port}`);
}); 